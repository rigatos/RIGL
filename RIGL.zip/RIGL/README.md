Magento 2 Update Product Details from Google Shopping
This extension allows you to update the details of a product in Magento 2 from Google Shopping. The extension uses the Google Shopping API to search for product details based on the product's SKU. The results of the search are returned as JSON. The extension then uses the helper Data to extract the product details from the JSON. The product details are then saved to the Product model.

Installation
Download the extension from the GitHub repository.
Unzip the archive.
Move the extension folder to the app/code/community/RIGL/GoogleShopping folder of Magento 2.
Run the command bin/magento setup:upgrade to install the extension.
Enable the extension in the Magento 2 admin panel.
Usage
To use the extension, click on the "Update Product Details from Google Shopping" icon in the Magento 2 admin panel. The icon will appear in the "Products" menu.

In the dialog box that appears, enter the SKU of the product that you want to update. Once you have entered the SKU, the extension will search for the product details from Google Shopping. The results of the search will appear in the dialog box.

You can select the fields that you want to update from the results of the search. The fields that can be updated include:

Title
Description
Weight
Brand
Manufacturer
Once you have selected the fields that you want to update, click on the "Update" button. The extension will update the relevant fields of the product in Magento 2.

Configuration
The extension has the following configuration options:

apiKey: The API key for the Google Shopping API.
apiSecret: The API secret for the Google Shopping API.
countryCode: The country code for the Google Shopping search.
You can configure these options in the etc/config.xml file of the extension.

Limitations
The extension currently has the following limitations:

It only supports the Greek language.
It can only update the fields listed above.
It can only update one product at a time.
I will try to improve the extension to address these limitations.

