<?php

namespace RIGL\GoogleShopping\Helper;

use GuzzleHttp\Client;

class Data
{
    /**
     * @var Client
     */
    private $client;

    /**
     * @var string
     */
    private $apiKey;

    /**
     * @var string
     */
    private $apiSecret;

    /**
     * @var string
     */
    private $countryCode;

    /**
     * @param Client $client
     * @param string $apiKey
     * @param string $apiSecret
     * @param string $countryCode
     */
    public function __construct(
        Client $client,
        string $apiKey,
        string $apiSecret,
        string $countryCode
    ) {
        $this->client = $client;
        $this->apiKey = $apiKey;
        $this->apiSecret = $apiSecret;
        $this->countryCode = $countryCode;
    }

    /**
     * @param string $sku
     * @return array|null
     */
    public function getProductDetailsFromGoogleShopping(string $sku): ?array
    {
        $url = 'https://content.googleapis.com/shopping/products/v1/products?q=sku:' . $sku . '&country=' . $this->countryCode;

        $headers = [
            'Authorization' => 'Bearer ' . $this->apiKey,
            'Accept' => 'application/json',
        ];

        $response = $this->client->get($url, [
            'headers' => $headers,
        ]);

        if ($response->getStatusCode() == 200) {
            $data = json_decode($response->getBody(), true);

            if (isset($data['products']) && isset($data['products'][0])) {
                return $data['products'][0];
            }
        }

        return null;
    }
}
