<?php

namespace RIGL\GoogleShopping\Model;

use Magento\Catalog\Model\Product;

class Product extends Product
{
    /**
     * @param string $field
     * @param mixed $value
     * @return $this
     */
    public function setData(string $field, $value): self
    {
        if ($field == 'rigl_google_shopping_title') {
            $this->setTitle($value);
        } elseif ($field == 'rigl_google_shopping_description') {
            $this->setDescription($value);
        } elseif ($field == 'rigl_google_shopping_weight') {
            $this->setWeight($value);
        } elseif ($field == 'rigl_google_shopping_brand') {
            $this->setBrand($value);
        } elseif ($field == 'rigl_google_shopping_manufacturer') {
            $this->setManufacturer($value);
        } else {
            parent::setData($field, $value);
        }

        return $this;
    }
}
