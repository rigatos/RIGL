<?php

namespace RIGL\GoogleShopping\Controller\Product;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;
use RIGL\GoogleShopping\Helper\Data;

class UpdateDetails extends Action
{
    /**
     * @var ProductRepositoryInterface
     */
    private $productRepository;

    /**
     * @var JsonFactory
     */
    private $resultJsonFactory;

    /**
     * @var Data
     */
    private $dataHelper;

    /**
     * @param Context $context
     * @param ProductRepositoryInterface $productRepository
     * @param JsonFactory $resultJsonFactory
     * @param Data $dataHelper
     */
    public function __construct(
        Context $context,
        ProductRepositoryInterface $productRepository,
        JsonFactory $resultJsonFactory,
        Data $dataHelper
    ) {
        $this->productRepository = $productRepository;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->dataHelper = $dataHelper;

        parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\Controller\Result\Json
     */
    public function execute()
    {
        $result = $this->resultJsonFactory->create();

        $sku = $this->getRequest()->getParam('sku');

        if (!$sku) {
            $result->setHttpResponseCode(400);
            $result->setData([
                'error' => 'Please enter a sku.'
            ]);
            return $result;
        }

        $product = $this->productRepository->get($sku);

        if (!$product) {
            $result->setHttpResponseCode(404);
            $result->setData([
                'error' => 'Product not found.'
            ]);
            return $result;
        }

        $fields = $this->getRequest()->getParam('fields');

        if (!$fields) {
            $fields = ['title', 'description', 'weight', 'brand', 'manufacturer'];
        }

        $productData = $this->dataHelper->getProductDetailsFromGoogleShopping($sku);

        if ($productData) {
            foreach ($fields as $field) {
                if (isset($productData[$field])) {
                    $product->setData($field, $productData[$field]);
                }
            }

            $this->productRepository->save($product);

            $result->setData([
                'success' => true
            ]);
        } else {
            $result->setHttpResponseCode(400);
            $result->setData([
                'error' => 'Product not found in Google Shopping.'
            ]);
        }

        return $result;
    }
}
